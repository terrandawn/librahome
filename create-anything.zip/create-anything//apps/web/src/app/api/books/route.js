import sql from "@/app/api/utils/sql";

// GET /api/books - List all books for a user
export async function GET(request) {
  try {
    const userId = request.headers.get("x-user-id");

    if (!userId) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status");
    const search = searchParams.get("search");
    const sortBy = searchParams.get("sortBy") || "date_added";
    const sortOrder = searchParams.get("sortOrder") || "DESC";

    let query = "SELECT * FROM books WHERE user_id = $1";
    const params = [userId];
    let paramCount = 1;

    if (status) {
      paramCount++;
      query += ` AND status = $${paramCount}`;
      params.push(status);
    }

    if (search) {
      paramCount++;
      query += ` AND (LOWER(title) LIKE LOWER($${paramCount}) OR LOWER(author) LIKE LOWER($${paramCount}))`;
      params.push(`%${search}%`);
    }

    const validSortColumns = [
      "title",
      "author",
      "date_added",
      "status",
      "updated_at",
    ];
    const sortColumn = validSortColumns.includes(sortBy)
      ? sortBy
      : "date_added";
    const order = sortOrder.toUpperCase() === "ASC" ? "ASC" : "DESC";

    query += ` ORDER BY ${sortColumn} ${order}`;

    const books = await sql(query, params);

    return Response.json({ books });
  } catch (error) {
    console.error("Error fetching books:", error);
    return Response.json({ error: "Failed to fetch books" }, { status: 500 });
  }
}

// POST /api/books - Create a new book
export async function POST(request) {
  try {
    const userId = request.headers.get("x-user-id");

    if (!userId) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const {
      title,
      author,
      isbn,
      publisher,
      publication_year,
      genre,
      cover_image_url,
      page_count,
      description,
      language = "en",
      format,
      condition,
      physical_location,
      date_acquired,
      status = "unread",
      tags = [],
    } = body;

    if (!title) {
      return Response.json({ error: "Title is required" }, { status: 400 });
    }

    // Insert book
    const [book] = await sql`
      INSERT INTO books (
        user_id, title, author, isbn, publisher, publication_year,
        genre, cover_image_url, page_count, description, language,
        format, condition, physical_location, date_acquired, status
      ) VALUES (
        ${userId}, ${title}, ${author}, ${isbn}, ${publisher}, ${publication_year},
        ${genre}, ${cover_image_url}, ${page_count}, ${description}, ${language},
        ${format}, ${condition}, ${physical_location}, ${date_acquired}, ${status}
      )
      RETURNING *
    `;

    // Add tags if provided
    if (tags && tags.length > 0) {
      for (const tag of tags) {
        await sql`
          INSERT INTO book_tags (book_id, tag)
          VALUES (${book.id}, ${tag})
        `;
      }
    }

    // Initialize reading progress if status is reading
    if (status === "reading" && page_count) {
      await sql`
        INSERT INTO reading_progress (book_id, user_id, total_pages, started_at)
        VALUES (${book.id}, ${userId}, ${page_count}, NOW())
      `;
    }

    return Response.json({ book }, { status: 201 });
  } catch (error) {
    console.error("Error creating book:", error);
    return Response.json({ error: "Failed to create book" }, { status: 500 });
  }
}
